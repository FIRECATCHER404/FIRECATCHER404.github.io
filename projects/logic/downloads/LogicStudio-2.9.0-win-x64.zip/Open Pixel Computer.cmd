@echo off
start "" "%~dp0LogicStudio.exe" "%~dp0pixel-256-computer.logic.json"
