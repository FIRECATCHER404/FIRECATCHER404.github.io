# Logic Studio 2.1 / RGB-8 v2

Run **Open Logic Studio.cmd** or **native/build/LogicStudio.exe**. This is a compiled Windows application: C++ simulation, a separate simulation thread, and Direct2D/DirectWrite drawing. It contains no browser runtime. All data stays local, and it needs no installation, server or internet connection.

The canvas opens with just its tiny top-left sidebar arrow. The desktop version is the main development version. The website retains the original editor and 16-byte CPU; v2 memory components require the desktop version. Existing browser circuit files import into the app.

## The better computer

- 8-bit A, X, Y and OUT registers, carry/zero/halt signals, and an 8-bit byte-addressed program counter.
- **256-byte program ROM** and **256-byte writable data RAM**.
- Two bytes per instruction: opcode followed by operand. Instructions without an operand use `00` as their second byte. Branches use even byte addresses; PC advances by two and wraps at 256.
- Direct and X-indexed load/store, full-byte immediates, arithmetic, bit operations, shifts, and conditional branches.
- 8×8, eight-color RGB framebuffer with pixel reads and writes. Tile instructions address a 4×4 matrix of 2×2 pixel blocks.
- Native hex/binary loading, a small label-based assembler, live byte-memory viewer, manual RAM edits, single-instruction stepping, and persistent circuit state.

The CPU and graphics use **3,271 inspectable nodes and 8,204 wires**, including 234 one-bit registers. RAM and ROM use reusable 256×1 memory chips: eight planes form a byte memory. The program ROM has two identical banks for simultaneous opcode and operand reads. RAM writes and CPU registers sample the same clock edge. There is no separate scripted CPU or ant renderer.

## Run Langton’s ant

The fresh computer already contains the 106-byte ant program, paused at its main loop with a white board and red ant. **Middle-click RUN** to start or stop it. Alternatively open **Relay → 01 RUN**, set its bit to `1` or `0`, and Apply. **Control panel → One CPU instruction** executes one instruction with RUN off; a complete ant move takes multiple instructions.

To reload it, open **Program bytes → Ant example → Load & reset**, then turn RUN on. You can also open `langtons-ant-4x4.asm` or paste `langtons-ant-4x4.hex`. **Assemble → hex** converts source to the exact bytes, with labels resolved. Loading stops RUN, clears RAM and the screen, and resets registers. The first four instructions initialize the board.

RAM **00–0F is the 4×4 byte matrix**, row by row. Each cell stores `00` (white) or `01` (black). X holds `y*4+x`; Y holds direction, `0=N, 1=E, 2=S, 3=W`. The red tile marks the ant without changing its underlying stored cell. At each move: read the byte; turn right on white or left on black; flip the byte; move forward. Edges wrap, making a 4×4 torus. F0 and F1 are scratch bytes. **Memory** shows every byte and allows hex edits while RUN and STEP are low.

## Enter your own program

Choose **Hex bytes** or **Assembly (v2)** in Program bytes. Open accepts `.bin`, `.hex`, `.txt` and `.asm`. Decimal operands use ordinary numbers; hexadecimal operands use `$FF` or `0xFF`. Labels use `name:` and comments begin with `;`. The assembler rejects unknown mnemonics, duplicate/missing labels, odd branch addresses, out-of-range operands and programs over 256 bytes. Old CPUs keep their original ISA and 16-byte limit.

For example, store A5 at RAM 80, read it through X and output it:

```asm
LDI 0xA5
STA 0x80
LDX 0x80
LDI 0
LDAX
OUT
HLT
```

The exact bytes are:

```text
10 A5 B0 80 C0 80 10 00 0E 00 03 00 01 00
```

Load & reset, then turn RUN on. OUT becomes `10100101` and HALT turns on. RAM 80 contains A5. Loading and manual memory edits are undoable.

## Instruction set

Every entry below takes two bytes. `n` is the second byte. Arithmetic wraps modulo 256. Carry means overflow for ADD, no borrow for SUB, or the shifted-out bit for SHL/SHR; other instructions preserve it. ZERO reflects A.

| Opcode | Assembly | Effect |
| --- | --- | --- |
| 00 | NOP | Advance PC |
| 01 | HLT | Hold PC and state until reset |
| 02 / 03 | IN / OUT | Read external input into A / copy A to OUT |
| 04 / 05 | TAX / TXA | Copy A to X / X to A |
| 06 / 07 | TAY / TYA | Copy A to Y / Y to A |
| 08 / 09 | INX / DEX | Increment / decrement X |
| 0A / 0B | INY / DEY | Increment / decrement Y |
| 0C / 0D | SHL / SHR | Shift A left / right, zero fill |
| 0E / 0F | LDAX / STAX | A = RAM[X] / RAM[X] = A |
| 10 | LDI n | A = n |
| 20 / 30 | ADD n / SUB n | A += n / A -= n |
| 40 / 50 / 60 | AND n / OR n / XOR n | Bitwise immediate operation on A |
| 70 / 80 / 90 | JMP n / JZ n / JNZ n | Branch always / if A is zero / if A is nonzero |
| A0 / B0 | LDA n / STA n | A = RAM[n] / RAM[n] = A |
| C0 / D0 | LDX n / LDY n | X = n / Y = n |
| E0 / E1 | PLOT n / PLOTA | Pixel at X = color n / A |
| E2 | CLEAR n | Fill screen with color n |
| E3 | PIXEL | A = color of pixel at X |
| E4 / E5 | TILE n / TILEA | 2×2 tile at X = color n / A |
| E6 | TILEGET | A = top-left pixel color of tile X |
| F0 / F1 | JC n / JNC n | Branch if carry is set / clear |

For ordinary pixels, `x=X&7`, `y=(X>>3)&7`. Tiles use `x=X&3`, `y=(X>>2)&3`. Colors use the low three bits: `0 black, 1 blue, 2 green, 3 cyan, 4 red, 5 magenta, 6 yellow, 7 white`. The high nibble selects immediate instructions 10–D0; their unused low nibble is ignored. Undefined system/graphics/F-group opcodes act as NOP, except FF also halts. Odd branch targets are rounded down by hardware; the assembler prevents them.

## Native controls and storage

The original mouse behavior is retained: drag hollow output circles to solid inputs; drag connected inputs away to disconnect/reattach; middle-click inputs; left-drag nodes freely with a small lift and shadow, then release to snap to the nearest grid cell; right-click settings/delete. Shift-drag selects INPUT nodes if any are enclosed, otherwise OUTPUT nodes. Relay sorts by exact X then Y. The selection action strip groups/titles the selected inputs or outputs; G does the same. Every grouped input has its own bit field, including groups larger than 32. Invalid Relay words show an inline error. G creates/titles a group. Ctrl+C/V copies selected nodes and internal wires; Ctrl+Z / Ctrl+Shift+Z undo/redo.

Middle-drag or Space+drag pans; the wheel zooms at the pointer; F fits a layer; Page Up/Down changes layers; F11 toggles fullscreen. V/P chooses Select/Pan; +/? zooms; / searches components; H opens help; Ctrl+S saves locally. Canvas tools includes zoom percentage/reset, Fit, Fullscreen, Undo/Redo, library/help controls and canvas status. There are 256 layers and exact decimal grid coordinates compatible with browser BigInt files, with zoom down to 1e-200. RGB blocks fill their cells edge to edge; other blocks are inset and rounded. The sidebar opens independent Components, Control panel, Relay, Canvas tools and Project panels. Components includes search and category filters. Settings changes canvas theme, simulation interval and work-batch multiplier; powered color stays light green.

At **0 ms**, native simulation runs continuously on its own thread, independently of display refresh. Keep the computer at 0 ms. Nonzero delays and the propagation-frame button expose individual Boolean propagation stages; the computer’s instruction button instead settles one shared clock edge. Rendering remains on the UI thread. Two frames form a complete pulse cycle. Simulation publishes revision-tagged state snapshots to the editor; painting never waits for a simulation batch. Autosave serializes and writes on a separate disk thread.

Autosave is **data/workspace.logic.json beside the executable**, every three seconds and on close. Keep the whole extracted folder in a writable location. Use Project → Export for portable backups. A malformed autosave is backed up as `.invalid-backup` before a fresh example is opened. `--fresh` skips restoring the autosave; `--data <folder>` selects another autosave directory. Windows may show an unsigned-app prompt; this build is not code-signed.

## UI frame-time fix in 2.1

The previous app shared a simulation mutex with drawing and performed JSON serialization/disk writes on the UI thread. A 12-second running-computer/panning test reproduced a worst frame interval of **1,182.8 ms**, including 71 intervals above 50 ms. With separate simulation and save ownership, the same final-build test measured **15.1 ms worst**, **13.8 ms at the 95th percentile**, and **zero intervals above 50 ms**. UI autosave queueing was below 1 ms; disk work happened in the background. These are local measurements on this PC, not a guarantee for every circuit or machine.

The native editor exposes the browser's sidebar tools, filters, searches, inspectors, selection actions, Relay, examples, project dialogs, placement settings and shortcuts. RAM, ROM, assembly, CPU stepping and the byte-memory viewer remain additional desktop tools. Controls use Win32 and the canvas uses Direct2D; no browser runtime is embedded.

## Validation and remaining limits

Native core tests compare 1,024 ant moves with a separate reference, including all 16 bytes, ant position/direction and all 64 RGB pixels. They also exercise every RAM address/value, assembler agreement with JavaScript, load/reset, saved clocks/memory, and 1,024 incremental-versus-synchronous simulation frames. Native UI checks exercise the actual Win32 controls, program loading, instruction steps, Relay, memory editing, settings and layers; screenshots and reports are under `native/build/`.

A dedicated same-circuit benchmark measured median throughput of **81,526 native instructions/second versus 6,281 JavaScript instructions/second**: about **13× faster**. Both engines ran 1,000 warmup frames followed by five runs of 10,000 frames from the same saved graphical computer. This measures engine throughput on this machine, not screen refresh rate or a universal speedup. Performance varies with circuit size and editing/viewing activity.

This release targets Windows x64. macOS/Linux/ARM builds, code signing, debugger breakpoints, stack/call instructions and interrupts are not included. Touch gestures and cross-machine Windows testing remain unverified. Build from source using **native/build.ps1 -Test** with Visual Studio C++ Build Tools; the executable needs only Windows system DLLs. Node is needed only to regenerate circuit example files, not to run the app.
