# Logic Studio 2.8.0 / Windows x64

Version 2.8 adds attachable LOG nodes and a Console, chips with zero inputs
or outputs, chip-library deletion, and normal OUTPUT nodes that accept
1-, 8-, or 16-bit signals. See [debugging and chips](debugging-and-chips.md).

Version 2.7.4 adds distinct send/receive/RGB tunnel icons in Components.
Each send-tunnel input now carries one bit, with 1-16 inputs per sender.
Old directional bus tunnels convert to one-bit tunnels and SPLIT/JOIN nodes
when loaded, preserving their connections and signals.

Version 2.7.3 displays bare gate symbols and wires inside custom nodes, with
no internal node tiles. Nested chips expand into the same schematic. Input
and output lines connect directly to the custom node's external pins.
Signals color the wires and individual input leads as the circuit runs.
Import `custom-node-diagram.logic.json` for the three-input OR / nested XOR example.

Version 2.7.1 adds Components > Custom for your created/imported chips, and
Components > Notes for comments. Custom definitions appear by name, remain
searchable, and update when created, imported, edited, or restored by undo/redo.

Version 2.7 improves keyboard navigation, button feedback, panel scrolling and
native rendering latency. See [GUI controls and measurements](gui-interactivity.md).

Version 2.6 adds freely positioned, resizable **COMMENT** annotations with
middle-click editing, and directional **SENDTUNNEL / RECEIVETUNNEL** nodes with 1-16 channels.
Senders have only inputs and automatically place their output-only receivers.
Open `LogicStudio.exe`, then Components from the small top-left sidebar arrow.
See [comments and multi-input tunnels](annotations-and-tunnels.md), or import
`comments-multi-tunnels.logic.json` for an example.

Open **Open Platformer Computer.cmd** to play Bytebound on the new native
8-bit computer. A/D or arrows move, Space/W/Up jumps, Shift runs, R restarts.
**Tab releases keyboard capture.** Use the small top-left arrow to open tools.

[Platformer controls, CPU, 2 GiB RAM and editable ROM guide](platformer-ls8.md)

The platformer and its native CPU/video chips are new in 2.5. The screen uses
128 × 128 individual pixel nodes. Its instructions, world, textures, collisions
and enemy behavior are editable in `platformer-ls8.asm`; direct hex and binary
ROM files are included. Game computer in the sidebar provides ROM editing,
Run/Stop/Reset, CPU/frame stepping, a RAM viewer and measured game FPS.

The CPU is native instruction-level hardware, with sparsely allocated byte RAM;
it is not assembled from individual Boolean gates. Sound is not implemented.
The app uses Windows native controls and Direct2D, with no embedded browser.

`LogicStudio.exe` opens your saved workspace. The example launcher imports a
fresh copy of the example; export your changes if you want a separate file.

Other examples and guides remain included:

* [RGB-16 gate computer](computer-16-bit.md) / Open RGB-16.cmd
* [Keyboard commands, chips and buses](chips-buses-keyboard.md) / Open Keyboard Computer.cmd
* [RGB-8 v2 gate computer](computer-v2.md)

Requires Windows x64. No installer, Python, or C++ runtime installation is needed.
