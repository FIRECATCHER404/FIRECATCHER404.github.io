@echo off
start "" "%~dp0LogicStudio.exe" "%~dp0platformer-8-bit.logic.json"
