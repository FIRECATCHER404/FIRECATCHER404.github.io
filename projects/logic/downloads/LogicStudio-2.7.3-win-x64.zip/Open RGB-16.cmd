@echo off
start "" "%~dp0LogicStudio.exe" "%~dp0computer-16-bit.logic.json"
