; Langton's ant: RAM 00–0F is a 4x4 byte matrix.
; X = cell index (y*4+x), Y = direction (N,E,S,W).
; White 00: turn right. Black 01: turn left. Wrap edges.
CLEAR 7
LDX 5
LDY 0
TILE 4
loop:
LDAX
XOR 1
STAX
JZ black
TILE 0
INY
JMP turned
black:
TILE 7
DEY
turned:
TYA
AND 3
TAY
JZ north
SUB 1
JZ east
SUB 1
JZ south
; West: preserve row and wrap the column.
TXA
AND 12
STA 0xF0
TXA
ADD 3
AND 3
JMP horizontal
east:
TXA
AND 12
STA 0xF0
TXA
ADD 1
AND 3
horizontal:
STA 0xF1
LDA 0xF0
; Add the column to row via X as a temporary counter.
TAX
LDA 0xF1
JZ atcolumn
columnloop:
INX
SUB 1
JNZ columnloop
atcolumn:
TILE 4
JMP loop
north:
TXA
SUB 4
JMP vertical
south:
TXA
ADD 4
vertical:
AND 15
TAX
TILE 4
JMP loop
