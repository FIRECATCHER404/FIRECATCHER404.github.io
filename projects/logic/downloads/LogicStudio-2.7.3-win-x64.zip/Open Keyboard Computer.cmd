@echo off
"%~dp0LogicStudio.exe" "%~dp0computer-16-bit-keyboard.logic.json"
